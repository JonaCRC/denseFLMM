# denseFLMM v0.1.3

## changes

- fix cross references
- fix news.md according to new checks


# denseFLMM v0.1.2

## changes

- replace rBind and cBind by rbind and cbind as they are depricated
